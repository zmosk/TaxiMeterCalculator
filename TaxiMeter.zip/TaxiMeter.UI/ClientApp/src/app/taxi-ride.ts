export interface TaxiRide {
  startDateOfRide: string;
  startTimeOfRide: string;
  minutesOver6Mph: number;
  milesUnder6Mph: number;
  totalFare: number;
}
