﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TaxiMeter.Common.Model;
using TaxiMeter.Services.Rules;

namespace TaxiMeter.Services.Test.Rules
{
    [TestClass]
    class NotInMotionRuleTest
    {
        //[TestMethod]
        //public void NotInMotionRuleShouldApply()
        //{
        //    var notInMotionRule = new NotInMotionRule();
        //    var taxiRide = new TaxiRide();

        //    var actualCharge = notInMotionRule.CalculateCharge(taxiRide);

        //    var expectedCharge = .35m;

        //    Assert.AreEqual(actualCharge, expectedCharge);
        //}

    }
}
